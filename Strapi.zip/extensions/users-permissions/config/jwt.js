module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'd6c46527-d751-4874-9e9a-c24ee547648d'
};